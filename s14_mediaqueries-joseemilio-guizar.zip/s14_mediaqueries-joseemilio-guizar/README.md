# S14_Mediaqueries-JoseEmilio-Guizar

A Pen created on CodePen.

Original URL: [https://codepen.io/JOSE-EMILIO-GUIZAR/pen/azdWezR](https://codepen.io/JOSE-EMILIO-GUIZAR/pen/azdWezR).

