# Reto de las cajas_JoseEmilio_JS

A Pen created on CodePen.

Original URL: [https://codepen.io/JOSE-EMILIO-GUIZAR/pen/ogbopPP](https://codepen.io/JOSE-EMILIO-GUIZAR/pen/ogbopPP).

